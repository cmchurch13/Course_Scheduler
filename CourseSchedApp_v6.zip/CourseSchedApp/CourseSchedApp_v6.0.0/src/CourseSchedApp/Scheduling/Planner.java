/*
 * Krizia Houston Buck
 * Planner Class in Scheduling
 * 11/09/2015
 */
package CourseSchedApp.Scheduling;

/**
 *
 * @author Krizia
 */
import CourseSchedApp.Course_Node_Controller.CondensedCourseNode;
import CourseSchedApp.Course_Node_Controller.Course;
import java.util.*;
import java.awt.*; 
import javax.swing.*; 

public class Planner{
    private final Color PANEL_PURP = new Color(100,0,100);
    private final Color PANEL_GREY = new Color(200,200,200);
    
    //Planner data members
    private static ArrayList<Semester> semesterList;
    private JPanel gridPanel;
    
    //Planner methods
    public Planner(){
        semesterList = new ArrayList();
        gridPanel = new JPanel();
        gridPanel.setLayout(new GridLayout(1,12,0,0));
        
        Semester temp;

        for(int i = 0; i < 12; i++){
            if(i%2 == 0){
                temp = new Semester(PANEL_PURP, PANEL_GREY, i+1);
            }
            else{
                temp = new Semester(PANEL_GREY, PANEL_PURP, i+1);
            }
            semesterList.add(temp);
        }
        
        for(Semester SP : semesterList){
            gridPanel.add(SP.getPanel());
        }
    }
    
    public static boolean checkAllForErrors(String courseName){
        for(Semester SP : semesterList)
            for(CondensedCourseNode CCN : SP.getCourseList()){
            if(CCN.getCourseName().equals(courseName)){
                JOptionPane.showMessageDialog(SP.getPanel(), "Course is already in the planner");
                return true;
            }
        }
        return false;
    }
    
    public JPanel getPanel(){
        return gridPanel;
    }
    
    public static ArrayList<Semester> getSemesters(){
        return semesterList;
    }
}
