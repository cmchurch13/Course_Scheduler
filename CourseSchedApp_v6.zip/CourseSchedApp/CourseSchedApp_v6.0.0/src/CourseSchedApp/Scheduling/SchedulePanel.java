/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author matthewmartens
 */

package CourseSchedApp.Scheduling;

import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class SchedulePanel{
    private JScrollPane scheduleScrollPane;
    private Planner planner;
    private JPanel gridPanel;
    
    //initialize private members to default values
    public SchedulePanel()
    {
        planner = new Planner();
        
        scheduleScrollPane = new JScrollPane(planner.getPanel());
        scheduleScrollPane.setVisible(true);
        
    }
  
    public Planner getPlanner(){
        return planner;
    }

    public void setPlanner(Planner plan){
        planner = plan;
    }
    
    public JScrollPane getScrollPane(){
        return scheduleScrollPane;
    }
    
    public void setScrollPane(JScrollPane pane){
        scheduleScrollPane = pane;
    }
    
    public JPanel getGridPanel(){
        return gridPanel;
    }
}