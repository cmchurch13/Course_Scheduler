/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CourseSchedApp.Scheduling;

import java.io.File;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Exporter {
   // private static JFrame frame = new JFrame();
    private JFileChooser chooser;
    private File file;
    private String outputString;
    
    
    public Exporter() {
        this.outputString = new String();
    
        chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);        
        chooser.setFileFilter(new FileNameExtensionFilter("CSV Files","csv"));

        int option = chooser.showSaveDialog(null);

        if(option == JFileChooser.APPROVE_OPTION) {
            file = chooser.getSelectedFile();
            if(fileExists()) {
                int overrideChoice = JOptionPane.showConfirmDialog(null, "Warning! File already exists. Do you want to override?","Warning!",JOptionPane.YES_NO_OPTION);
                if(overrideChoice == JOptionPane.YES_OPTION) {
                    parseData();
                    saveFile();
                }
            } else {
                parseData();
                saveFile();
            }
        }
    }
    
    private boolean fileExists(){
        if(file.exists()) {
            return true;
        } else {
            return false;
        }
    }
    
    private void parseData(){
        int i = 0;
        StringBuilder builder = new StringBuilder();
        
        for(Semester S : Planner.getSemesters()){
            builder.append("\n");
            builder.append(S.toString());
        }
        
        builder.trimToSize();
        System.out.println("Saved String is: " + builder.toString());
        outputString = builder.toString();
    }
    
    private void saveFile() {
        try {
            PrintWriter writer;
            if(file.toString().contains(".csv")) {
                writer = new PrintWriter(file);
            } else {
                writer = new PrintWriter(file + ".csv");
            }
            writer.print(outputString);
            writer.close();
        } catch (Exception e) {
            System.out.println("Whoops");
        }
        
    }
}

