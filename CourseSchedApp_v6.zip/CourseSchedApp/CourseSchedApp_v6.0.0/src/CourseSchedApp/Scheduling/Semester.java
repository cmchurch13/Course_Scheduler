/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CourseSchedApp.Scheduling;

import CourseSchedApp.Course_Node_Controller.CondensedCourseNode;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Chris
 */
public class Semester extends DropTargetAdapter{
    private JPanel panel;
    private DropTarget dropTarget;
    private int totalHours;
    private ArrayList<CondensedCourseNode> courseList;
    private JLabel semTitle;
    
    public Semester(Color background, Color font, int semCount){
        semTitle = new JLabel("Semester " + semCount);
        courseList = new ArrayList();
        totalHours = 0;
        
        panel = new JPanel(new GridLayout(8,1,5,5));
        panel.setBackground(background);
        panel.setPreferredSize(new Dimension(200,100));
        panel.setSize(new Dimension(200,100));
        
        semTitle.setFont(new Font("serif",1,20));
        semTitle.setHorizontalAlignment(JLabel.CENTER);
        semTitle.setForeground(font);
        
        panel.add(semTitle);
        
        dropTarget = new DropTarget(panel, DnDConstants.ACTION_COPY, this, true, null);
    }
    
    @Override
    public void drop(DropTargetDropEvent evt){
        DataFlavor nodeFlavor = new DataFlavor(CondensedCourseNode.class, "Condensed Course Node");
        
        try{
            Transferable transfer = evt.getTransferable();
            CondensedCourseNode newNode = (CondensedCourseNode) transfer.getTransferData(nodeFlavor);
       
            if(evt.isDataFlavorSupported(nodeFlavor) && !checkForErrors(newNode)){
                evt.acceptDrop(DnDConstants.ACTION_COPY);
                
                JButton temp = newNode.getRemoveButton();
                
                temp.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        JButton button = (JButton) e.getSource();
                        CondensedCourseNode removeNode = (CondensedCourseNode) button.getParent();
                        JPanel parent = (JPanel) button.getParent().getParent();
                        totalHours -= removeNode.getCreditHours();
                        courseList.remove(removeNode);
                        parent.remove(removeNode);
                        parent.repaint();
                        parent.revalidate();
                    }
                });
                totalHours += newNode.getCreditHours();
                
                courseList.add(newNode);
                panel.add(newNode);
                
                panel.revalidate();
                panel.repaint();
                
                evt.dropComplete(true);
                return;
            }
            evt.rejectDrop();
        } catch (Exception e) {
        e.printStackTrace();
        evt.rejectDrop();
      }
    }
    
    public boolean checkForErrors(CondensedCourseNode node){
        Color cannotTake = new Color(150,0,0);
        
        if(courseList.size() > 6){
            JOptionPane.showMessageDialog(panel, "The maximum amount of COURSES has been placed in this semester");
            return true;
        }
        else if(totalHours + node.getCreditHours() > 18){
            JOptionPane.showMessageDialog(panel, "The maximum amount of HOURS has been placed in this semester");
            return true;
        }
        else if(node.getColorPanel().getBackground().getRGB() == cannotTake.getRGB()){
            JOptionPane.showMessageDialog(panel, "You have not taken the required PREREQUISITES\nfor this course");
        }
        
        return Planner.checkAllForErrors(node.getCourseName());
    }
    
    public JPanel getPanel(){
        return panel;
    }
    
    public ArrayList<CondensedCourseNode> getCourseList(){
        return courseList;
    }
    
    @Override
    public String toString(){
        String totalString = new String(semTitle.getText() + ",");
        for(CondensedCourseNode CCN : courseList){
            totalString = totalString.concat(CCN.getCourseName() + ",");
        }
     
        return totalString;
    }
}
