package CourseSchedApp.Administration;

import CourseSchedApp.Course_Node_Controller.MainInterface;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

        

public class AdminLauncher extends JFrame{
	public static void main(String args[]){
                AdminLauncher gui = new AdminLauncher();
		Container c = gui.getContentPane();
                c.setLayout(new BorderLayout());
                
                JButton adminLogin = new JButton("Admin Login");
                adminLogin.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        LogInUI login = new LogInUI();
                    }
                });
                JButton mainUIButton = new JButton("Course Scheduler");
                mainUIButton.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        MainInterface mainUI = new MainInterface();
                    }
                });

                JPanel mid = new JPanel();
                mid.setLayout(new FlowLayout());
               
                c.add(mid,BorderLayout.CENTER);
                mid.add(mainUIButton);
                mid.add(adminLogin);
                
                gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                gui.setSize(800,800);
                gui.setVisible(true);
      
	}
}
