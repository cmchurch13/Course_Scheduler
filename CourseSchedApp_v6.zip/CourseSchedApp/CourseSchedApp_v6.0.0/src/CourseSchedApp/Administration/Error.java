package CourseSchedApp.Administration;

public class Error {
    private int id;
    private String description;
    private String date;
    
    Error(int id, String desc, String date){
        this.id = id;
        this.description = desc;
        this.date = date;
    }
}