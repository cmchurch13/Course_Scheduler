/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CourseSchedApp.Administration;
import java.awt.HeadlessException;
import CourseSchedApp.Program_Modeling.*;
import CourseSchedApp.Program_Modeling.QueryBuilder;

import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Justin, Jaya
 */
public class LogInUI extends javax.swing.JFrame {

    /**
     * Creates new form LogIn
     */
    public LogInUI() {
        initComponents();
        setVisible(true);
        //connect=DBConnection.dbConnector();
		
    }
    public void close()
    {
        WindowEvent winclose= new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winclose);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Username_Label = new javax.swing.JLabel();
        Password_Label = new javax.swing.JLabel();
        Username_Value = new javax.swing.JTextField();
        Password_Value = new javax.swing.JPasswordField();
        Back_Button = new javax.swing.JButton();
        Login_Button = new javax.swing.JButton();
        Title = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(0, 153, 153));
        setForeground(new java.awt.Color(102, 0, 102));

        Username_Label.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        Username_Label.setText("Username");

        Password_Label.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        Password_Label.setText("Password");

        Username_Value.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        Password_Value.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        Back_Button.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Back_Button.setText("BACK");

        Login_Button.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Login_Button.setText("LOGIN");
        Login_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Login_ButtonActionPerformed(evt);
            }
        });

        Title.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        Title.setText("Administrator LogIn");
        Title.setDebugGraphicsOptions(javax.swing.DebugGraphics.FLASH_OPTION);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Back_Button)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(Username_Label)
                        .addComponent(Password_Label)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(Login_Button)
                        .addGap(62, 62, 62))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Username_Value, javax.swing.GroupLayout.DEFAULT_SIZE, 126, Short.MAX_VALUE)
                            .addComponent(Password_Value))
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(Title, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 135, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(Title, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(Username_Label)
                        .addGap(49, 49, 49))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(Username_Value, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Password_Label)
                    .addComponent(Password_Value, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(59, 59, 59)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Back_Button)
                    .addComponent(Login_Button))
                .addGap(107, 107, 107))
        );

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-581)/2, (screenSize.height-545)/2, 581, 545);
    }// </editor-fold>//GEN-END:initComponents

    private void Login_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Login_ButtonActionPerformed
        try{
				String query=String.format("select * from logindetails where UserName = '%s' and Password = '%s'", Username_Value.getText(), Password_Value.getText());

					
				ResultSet rs = QueryBuilder.executeStatement(query);
				if(!rs.next())	{
						JOptionPane.showMessageDialog(null, "user credentials are wrong.Try again with correct credentials");
        		}
		        else{
					close();
		            AdminHome ui= new AdminHome();
		        }
        
		}
		catch(SQLException | HeadlessException e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
    }

    /**
     * @param args the command line arguments
     */
   /* public static void main(String args[]) {
        /*
         * Set the Nimbus look and feel
         */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /*
         * If Nimbus (introduced in Java SE 6) is not available, stay with the
         * default look and feel. For details see
         * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LogInUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /*
         * Create and display the form
         
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LogInUI().setVisible(true);
            }
        });
    }*/
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Back_Button;
    private javax.swing.JButton Login_Button;
    private javax.swing.JLabel Password_Label;
    private javax.swing.JPasswordField Password_Value;
    private javax.swing.JLabel Title;
    private javax.swing.JLabel Username_Label;
    private javax.swing.JTextField Username_Value;
    // End of variables declaration//GEN-END:variables
    
}
