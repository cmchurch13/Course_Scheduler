package CourseSchedApp.Administration;
import java.awt.*;
import java.sql.*;

import javax.swing.*;


import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import CourseSchedApp.Program_Modeling.QueryBuilder;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Update_Remove extends JFrame {

	/**
	 * Launch the application.
	 */
	/*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Update_Remove frame = new Update_Remove();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/
	/**
	 * Create the frame.
	 */
	Connection connect= null;
	public Update_Remove() {
		setVisible(true);
		getContentPane().setBackground(new Color(128, 0, 128));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(200, 200, 863, 777);
		getContentPane().setLayout(null);
		//Add Scroll pane
		JScrollPane scroll= new JScrollPane();
		scroll.setBounds(12,0,821,534);
		getContentPane().add(scroll);
		//Table
		final JTable table = new JTable(){
		public Component prepareRenderer(TableCellRenderer renderer, int row, int column){
	        Component returnComp = super.prepareRenderer(renderer, row, column);
	        Color alternateColor = new Color(252,242,206);
	        Color whiteColor = Color.WHITE;
	        if (!returnComp.getBackground().equals(getSelectionBackground())){
	            Color bg = (row % 2 == 0 ? alternateColor : whiteColor);
	            returnComp .setBackground(bg);
	            bg = null;
	        }
			return returnComp;
		}
		};
		scroll.setViewportView(table);
	
        table.setBackground(new Color(252,242,206));
        table.setForeground(Color.DARK_GRAY);
        table.setRowHeight(24);
        table.setFont(new Font("Arial", Font.BOLD, 16));
		//Model of Table
		final DefaultTableModel model = new DefaultTableModel()
		{
			public Class<?> getColumnClass(int column)
			{
				switch(column)
				{
				case 0:
				return String.class;
				case 1:
					return String.class;
				case 2:
					return String.class;
				case 3:
					return String.class;
				case 4:
					return String.class;
                               /* case 5:
					return String.class;
                                 case 6:
					return String.class;
                                 case 7:
					return String.class;
                                 case 8:
					return String.class;
                                 case 9:
					return String.class;*/
				case 5:
					return Boolean.class;
					default :
						return String.class;
						
					}
				}
		};
		//Assign Model to table
		table.setModel(model);
               model.addColumn("DEPT.");
		model.addColumn("Name");
                model.addColumn("CRN");
		model.addColumn("Credits");
		model.addColumn("PREREQ1");
               // model.addColumn("PREREQ2");
               // model.addColumn("PREREQ3");
               // model.addColumn("PREREQ4");
		//model.addColumn("Description");
		model.addColumn("Selected");
		table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 18));
		
			try
			{
			String Name;
			//String Desc;
			String Credits;
			String Prereq1;
                       /* String Prereq2;
                        String Prereq3;
                        String Prereq4;*/
			String Dept;
                        String CRN;
		String query1="select SCBCRSE_SUBJ_CODE,SCBCRSE_CRSE_NUMB,SCBCRSE_TITLE,SCBCRSE_CREDIT_HR_LOW,SCBCRSE_PREREQ_1 from courseinfo";
		
		//PreparedStatement pst2=connect.prepareStatement(query2);
		ResultSet rs= QueryBuilder.executeStatement(query1);
		//ResultSet rs1=pst2.executeQuery();
		//int count=rs1.getInt(1);
		//JOptionPane.showMessageDialog(null, "dataconnection is good so far");
		
		//JCheckBox chk = new JCheckBox("New check box");
		while (rs.next()) {
            //Dept=rs.getString("SCBCRSE_SUBJ_CODE");
            // Name = rs.getString("SCBCRSE_TITLE");
           // Desc = rs.getString("description");
            //Credits = rs.getString("SCBCRSE_CREDIT_HR_LOW");
           // Prereq1 = rs.getString("SCBCRSE_PREREQ_1");
            //Prereq2=rs.getString("SCBCRSE_PREREQ_2");
            //Prereq3=rs.getString("SCBCRSE_PREREQ_3");
            //Prereq4=rs.getString("SCBCRSE_PREREQ_4");
           // CRN=rs.getString("SCBCRSE_CRSE_NUMB");
             Dept=rs.getString(1);
             Name = rs.getString(3);
            //Desc = rs.getString(2);
            Credits = rs.getString(4);
            Prereq1 = rs.getString(5);
           /* Prereq2=rs.getString(6);
            Prereq3=rs.getString(7);
            Prereq4=rs.getString(8);*/
            CRN=rs.getString(2);
            model.addRow(new Object[]{Dept,Name,CRN, Credits, Prereq1,false});
        }
	}
	catch(Exception e)
	{
		JOptionPane.showMessageDialog(null, e);
	}
			
	//JOptionPane.showMessageDialog(null, table.getRowCount());
	
	//Obtain selected row
	JButton Update_Button = new JButton("Update");
        Update_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                            String col=null;
					boolean checked=false;
					 try
					 {
						 for(int i=0;i<table.getRowCount() - 1;i++)
							{
						   checked=Boolean.valueOf(table.getValueAt(i,5).toString());
						   col=table.getValueAt(i,2).toString();
						   if(checked)
							 {
								 JOptionPane.showMessageDialog(null, col+" will be Opened for Update");
                                                                 UpdateCourse uc = new UpdateCourse();
                                                                 uc.setVisible(true);
 
								String sql = String.format("select* from courseinfo where SCBCRSE_CRSE_NUMB=%s", col);
								ResultSet rs=QueryBuilder.executeStatement(sql);
                                while(rs.next())
                                {
                                                                    
	                                String course=rs.getString(3);
	                                String title=rs.getString(2);
	                                String desc=rs.getString(9);
	                                String credit=rs.getString(4);
	                                String prereq=rs.getString(5);
	                                String prereq2=rs.getString(6);
	                                String prereq3=rs.getString(7);
	                                String prereq4=rs.getString(8);
                                    
                                   uc.NAME_Text.setText(course);
                                   uc.CRN_Text.setText(title);
                                   uc.Description_Text.setText(desc);
                                   uc.Credit_Text.setText(credit);
                                   uc.Prereq1_Text.setText(prereq);
                                   uc.Prereq2_Text.setText(prereq2);
                                   uc.Prereq3_Text.setText(prereq3);
                                   uc.Prereq4_Text.setText(prereq4);

						        }
								
							 }
							
							}
						 
						 
						}
                   
                                         
				catch(HeadlessException | SQLException ex){
					JOptionPane.showMessageDialog(null, ex);
				}
                        }
                            
                        
        });
	
        Update_Button.setFont(new Font("Tahoma", Font.PLAIN, 18));
	Update_Button.setBounds(81, 547, 97, 41);
	getContentPane().add(Update_Button);
		JButton remove_Button = new JButton("Remove");
		remove_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					//JOptionPane.showMessageDialog(null, "I'm here");
					
                                        String col=null;
					boolean checked=false;
                                        
					 try
					 {
						 for(int i=0;i<table.getRowCount();i++)
							{
						   checked=Boolean.valueOf(table.getValueAt(i,5).toString());
						   col=table.getValueAt(i,1).toString();
						   if(checked)
							 {
								 JOptionPane.showMessageDialog(null, col+" will be removed");
								 String sql = String.format("delete from courseinfo where SCBCRSE_TITLE='%s'", col);
								 
								int result = QueryBuilder.updateStatement(sql);
								if (table.getSelectedRow() != -1) {
						            // remove selected row from the model
						            model.removeRow(table.getSelectedRow());
                                                           
						        }
								
							 }
							
							}
						 
						 
						}
				catch(Exception ex){
					JOptionPane.showMessageDialog(null, ex);
				}
				
				
				
			}
		});
		table.addNotify();
		remove_Button.setFont(new Font("Tahoma", Font.PLAIN, 18));
		remove_Button.setBounds(614, 559, 110, 41);
		getContentPane().add(remove_Button);
		
		
		
	}
}
