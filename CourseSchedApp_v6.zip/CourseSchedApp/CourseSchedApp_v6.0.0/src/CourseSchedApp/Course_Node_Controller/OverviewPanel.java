/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CourseSchedApp.Course_Node_Controller;

import CourseSchedApp.Course_Node_Controller.CourseNodeManager.CheckTaken;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Calvin
 */
public class OverviewPanel extends JPanel {
    private GridBagConstraints cons = new GridBagConstraints();
    private JPanel colorPanel = new JPanel();                                //Color bar at the top of a course (RED = can't take, BLUE = can take, GREEN = have taken and passed)
    private JTextArea classNameTextArea;
    private JCheckBox takenCheckBox = new JCheckBox("Taken");                //Check box for student to choose which courses they have taken
    private JLabel creditHoursLabel = new JLabel("Credit Hours:");
    private JTextField creditHourTextField;
    private JLabel upperCoreLabel = new JLabel("Upper Core:");
    private JTextField upperCoreTextField;
    private String dept;
    private String name;
    private String id;
    
    private final Color COLOR_BLUE = new Color(0,0,150);
    private final Color COLOR_DEFAULT = new Color(200,200,200);
    
    public OverviewPanel() {
        setLayout(new GridBagLayout());
        
        /* Field Initializations */
        classNameTextArea = new JTextArea("NONE 0000 Empty Class");
        creditHourTextField = new JTextField("0");
        upperCoreTextField = new JTextField("NEVER");
        upperCoreTextField.setBackground(COLOR_DEFAULT);
        takenCheckBox.setBackground(COLOR_DEFAULT);
        creditHourTextField.setBackground(COLOR_DEFAULT);
        colorPanel.setBackground(COLOR_BLUE);
        classNameTextArea.setBackground(COLOR_DEFAULT);
        dept = "CSCI";
        name = "Empty Class";
        id = "0000";
        
        creditHourTextField.setEditable(false);
        upperCoreTextField.setEditable(false);
        colorPanel.setBackground(COLOR_BLUE);
        classNameTextArea.setEditable(false);
        creditHourTextField.setBorder(null);
        upperCoreTextField.setBorder(null);
        
        assemblePanel();
    }
    
     public OverviewPanel(CheckTaken listener, Color COLOR_OVER, Course c) {
        setLayout(new GridBagLayout());
        
        /* Field Initializations */
        classNameTextArea = new JTextArea(c.getDepartment() + " " + c.getID() + "\n" + c.getName());
        creditHoursLabel = new JLabel("Credit Hours:");
        upperCoreTextField = new JTextField(c.getUpperCore());
        creditHourTextField = new JTextField(String.valueOf(c.getCredithrs()));
        upperCoreTextField.setBackground(COLOR_OVER);
        takenCheckBox.setBackground(COLOR_OVER);
        creditHourTextField.setBackground(COLOR_OVER);
        colorPanel.setBackground(COLOR_BLUE);
        classNameTextArea.setBackground(COLOR_DEFAULT);
        takenCheckBox.addActionListener(listener);
        dept = c.getDepartment();
        name = c.getName();
        id = c.getID();
        
        creditHourTextField.setEditable(false);
        upperCoreTextField.setEditable(false);
        colorPanel.setBackground(COLOR_BLUE);
        classNameTextArea.setEditable(false);
        creditHourTextField.setBorder(null);
        upperCoreTextField.setBorder(null);
        
        assemblePanel();
    }
     
     public OverviewPanel(OverviewPanel op){
         setLayout(new GridBagLayout());
        
        /* Field Initializations */
        classNameTextArea = new JTextArea();
        creditHourTextField = new JTextField();
        upperCoreTextField = new JTextField(op.getUpperCore());
        upperCoreTextField.setBackground(COLOR_DEFAULT);
        takenCheckBox.setBackground(COLOR_DEFAULT);
        creditHourTextField.setBackground(COLOR_DEFAULT);
        colorPanel.setBackground(COLOR_BLUE);
        classNameTextArea.setBackground(COLOR_DEFAULT);
        
        creditHourTextField.setEditable(false);
        upperCoreTextField.setEditable(false);
        colorPanel.setBackground(COLOR_BLUE);
        classNameTextArea.setEditable(false);
        creditHourTextField.setBorder(null);
        upperCoreTextField.setBorder(null);
         
        classNameTextArea.setText(op.getCourse());
        creditHourTextField.setText(op.getCreditHour());
        takenCheckBox.addActionListener(op.getListener());
        dept = op.getDepartment();
        name = op.getCourseName();
        id = op.getId();
        
         
        assemblePanel();
     }
    
    private void assemblePanel(){
        setColorConstraints(cons);
        add(colorPanel,cons);
        cons.gridy++;
        setInfoConstraints(cons);
        cons.ipadx = 5;
        add(classNameTextArea,cons);
        cons.gridx++;
        add(takenCheckBox, cons);
        cons.gridy++;
        cons.gridx--;
        cons.weighty = 0.5;
        add(creditHoursLabel, cons);
        cons.gridx++;
        add(creditHourTextField, cons);
        cons.gridy++;
        cons.gridx--;
        add(upperCoreLabel, cons);
        cons.gridx++;
        add(upperCoreTextField, cons);
    }
    
     private void setColorConstraints(GridBagConstraints c) {
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 3;
        c.gridheight = 1;
        c.fill = GridBagConstraints.BOTH;
        c.anchor = GridBagConstraints.EAST;
        c.weightx = 1.0;
        c.weighty = 1.0;
        c.ipadx = 0;
        c.ipady = 0;
    }
     
     private void setInfoConstraints(GridBagConstraints c){
        c.gridwidth = 1;
        c.insets = new Insets(3,3,3,3);
    }
     
    public String getCreditHour(){
        return creditHourTextField.getText();
    }
    
    public String getOffered(){
        return upperCoreTextField.getText();
    }
    
    public String getCourse(){
        return classNameTextArea.getText();
    }
    
    public String getDepartment(){
        return dept;
    }
    
    public ActionListener getListener(){
        return takenCheckBox.getActionListeners()[0];
    }
    
    public String getCourseName(){
        return name;
    }
    
    public String getId(){
        return id;
    }
    
    public Color getStatusColor(){
        return colorPanel.getBackground();
    }
    
    public String getUpperCore(){
        return upperCoreTextField.getText();
    }
}
