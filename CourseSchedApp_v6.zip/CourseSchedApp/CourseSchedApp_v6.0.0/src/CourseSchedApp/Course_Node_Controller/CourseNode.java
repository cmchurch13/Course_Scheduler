/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CourseSchedApp.Course_Node_Controller;

import CourseSchedApp.Course_Node_Controller.CourseNodeManager.CheckTaken;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.awt.dnd.DragSourceDragEvent;
import java.awt.dnd.DragSourceDropEvent;
import java.awt.dnd.DragSourceEvent;
import java.awt.dnd.DragSourceListener;
import javax.swing.JTabbedPane;

/**
 *
 * @author Calvin
 */
public class CourseNode extends JTabbedPane implements DragGestureListener, DragSourceListener{
    /* Global Constants */
    private final Color COLOR_PANE = new Color(150,150,150);
    private final Color COLOR_OVER = new Color(200,200,200);
    private final Color COLOR_PRER = new Color(200,200,200);
    
    /* Global Variable Declarations and Initializations */
    private Font courseFont = new Font("Serif",0,18);
    private Font prereqFont = new Font("Serif",0,18);
    
    private OverviewPanel overviewPan;
    private PrerequisitePanel prerequisitesPan1;
    private PrerequisitePanel prerequisitesPan2;
    private DragSource dragSource;
    private DataFlavor flavor = new DataFlavor(CondensedCourseNode.class, "Condensed Course Node");
    private String toolTip = new String();
    
    /**
     * Constructor: 0 Arguments
     */
    public CourseNode(){
        dragSource = new DragSource();
        dragSource.createDefaultDragGestureRecognizer(this, DnDConstants.ACTION_COPY, this);
        
        overviewPan = new OverviewPanel();
        prerequisitesPan1 = new PrerequisitePanel();
        prerequisitesPan2 = new PrerequisitePanel();
        
        /* Miscellaneous Component Edits */
        this.setBackground(COLOR_PANE);
        overviewPan.setBackground(COLOR_OVER);
        prerequisitesPan1.setBackground(COLOR_PRER);
        
        
        //Safeguard against font-growth infinite loop
        overviewPan.setMaximumSize(new Dimension(400,400));
        prerequisitesPan1.setMaximumSize(new Dimension(400,400));
        
        changeFont(overviewPan, courseFont);
        changeFont(prerequisitesPan1, prereqFont);
        setTabLayoutPolicy(JTabbedPane.WRAP_TAB_LAYOUT);
        setFont(courseFont);
        add("Overview", overviewPan);
        add("Prerequisites 1&2", prerequisitesPan1);
        add("Prerequisites 3&4", prerequisitesPan2);
    }
    
    /**
     * Creates a course pain based on course information passed in to it in @c
     * @param c 
     * @param lstnr 
     */
    public CourseNode(Course c, CheckTaken lstnr){
        dragSource = new DragSource();
        dragSource.createDefaultDragGestureRecognizer(this, DnDConstants.ACTION_COPY, this);
        
        overviewPan = new OverviewPanel(lstnr, COLOR_OVER,c);
        prerequisitesPan1 = new PrerequisitePanel(c, COLOR_PRER, 1);
        prerequisitesPan2 = new PrerequisitePanel(c, COLOR_PRER, 2);
        
        /* Miscellaneous Component Edits */
        this.setBackground(COLOR_PANE);
        overviewPan.setBackground(COLOR_OVER);
        prerequisitesPan1.setBackground(COLOR_PRER);
        this.setToolTipText(c.getDescription());
        toolTip = c.getDescription();
        
        
        //Safeguard against font-growth infinite loop. Ironically, its a failure
        overviewPan.setMaximumSize(new Dimension(400,400));
        prerequisitesPan1.setMaximumSize(new Dimension(400,400));
        
        changeFont(overviewPan, courseFont);
        changeFont(prerequisitesPan1, prereqFont);
        prerequisitesPan1.setFont(prereqFont);
        setTabLayoutPolicy(JTabbedPane.WRAP_TAB_LAYOUT);
        setFont(courseFont);
        add("Overview", overviewPan);
        add("Prerequisites 1&2", prerequisitesPan1);
        add("Prerequisites 3&4", prerequisitesPan2);
        
    }
    
    public CourseNode(CourseNode cn){
        dragSource = new DragSource();
        dragSource.createDefaultDragGestureRecognizer(this, DnDConstants.ACTION_COPY, this);
        
        overviewPan = new OverviewPanel(cn.getOverview());
        prerequisitesPan1 = new PrerequisitePanel(cn.getPrerequisite1());
        prerequisitesPan2 = new PrerequisitePanel(cn.getPrerequisite2());
        
        /* Miscellaneous Component Edits */
        this.setBackground(COLOR_PANE);
        overviewPan.setBackground(COLOR_OVER);
        prerequisitesPan1.setBackground(COLOR_PRER);
        
        
        //Safeguard against font-growth infinite loop
        overviewPan.setMaximumSize(new Dimension(400,400));
        prerequisitesPan1.setMaximumSize(new Dimension(400,400));
        
        changeFont(overviewPan, courseFont);
        changeFont(prerequisitesPan1, prereqFont);
        setTabLayoutPolicy(JTabbedPane.WRAP_TAB_LAYOUT);
        setFont(courseFont);
        add("Overview", overviewPan);
        add("Prerequisites 1&2", prerequisitesPan1);
        add("Prerequisites 3&4", prerequisitesPan2);
        setToolTipText(cn.getDescription());
        toolTip = cn.getDescription();
    }
    
    public String getDepartment(){
        return overviewPan.getDepartment();
    }
    
    public int getCreditHours(){
        return Integer.parseInt(overviewPan.getCreditHour());
    }
    
    public OverviewPanel getOverview(){
        return overviewPan;
    }
    
    public PrerequisitePanel getPrerequisite1(){
        return prerequisitesPan1;
    }
    
    public PrerequisitePanel getPrerequisite2(){
        return prerequisitesPan2;
    }
    
    public String getDescription(){
        return toolTip;
    }
    
    private static void changeFont ( Component component, Font font ){
        component.setFont ( font );
        if ( component instanceof Container ){
            for ( Component child : ( ( Container ) component ).getComponents () ){
                changeFont ( child, font );
            }
        }
    }
    
    @Override
    public void dragGestureRecognized(DragGestureEvent evt) {
      CondensedCourseNode newCondensed = new CondensedCourseNode(this);     
      dragSource.startDrag(evt, DragSource.DefaultCopyDrop, newCondensed, this);
    }

    @Override
    public void dragEnter(DragSourceDragEvent evt) {
      System.out.println("enters");
    }

    @Override
    public void dragOver(DragSourceDragEvent evt){
    }

    @Override
    public void dropActionChanged(DragSourceDragEvent evt) {
      System.out.println("changes the drag action between copy or move");
    }

    @Override
    public void dragDropEnd(DragSourceDropEvent evt) {
      System.out.println("finishes or cancels the drag operation");
    }

    @Override
    public void dragExit(DragSourceEvent evt) {
      System.out.println("leaves");
    }
}
