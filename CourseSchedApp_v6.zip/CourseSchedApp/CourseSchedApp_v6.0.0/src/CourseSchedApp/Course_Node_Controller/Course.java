/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CourseSchedApp.Course_Node_Controller;

import java.util.ArrayList;

/**
 *
 * @author Calvin
 */
public class Course {
    private String ID;
    private int credithrs;
    private String name;
    private String department;
    private String upperCore;
    private String description;
    private ArrayList<String> prerequisites;
    private ArrayList<String> requiredFor;
    
    //Mock constructor for testing purposes
    public Course(){
        this("Computer Science I");
    }
    public Course( String named ){
        this("1470", 3, named, "CSCI", "Always");
    }
    
    public Course(String id, int credits, String named, String dpt, String offrd, String prereq_1, String prereq_2, String descr){
        ID = id;
        credithrs = credits;
        name = named;
        department = dpt;
        upperCore = offrd;
        description = descr;
        prerequisites = new ArrayList();
        
        prerequisites.add(prereq_1);
        prerequisites.add(prereq_2);
    }
    
    public Course ( String id, int credits, String named, String dpt, String offrd, String prereq_1){
        ID= id;
        credithrs = credits;
        name = named;
        department = dpt;
        upperCore = offrd;
        prerequisites = new ArrayList();
        
        prerequisites.add(prereq_1);
        prerequisites.add("NONE");
    }
    
    public Course ( String id, int credits, String named, String dpt, String offrd){
        ID= id;
        credithrs = credits;
        name = named;
        department = dpt;
        upperCore = offrd;
        prerequisites = new ArrayList();
        prerequisites.add("NONE");
        prerequisites.add("NONE");
        requiredFor = new ArrayList();
        
    }
    
    public String getID(){
        return ID;
    }

    public int getCredithrs(){
        return credithrs;
    }
    
    public String getName(){
        return name;
    }
    
    public String getDepartment(){
        return department;
    }
    
    public String getUpperCore(){
        return upperCore;
    }
    
    public String getDescription(){
        return description;
    }
    
    public ArrayList<String> getPrerequisites(){
        return prerequisites;
    }
    
    public ArrayList<String> getRequired(){
        return requiredFor;
    }
    
    public void setID(String ident){
        ID = ident;
    }
    
    public void setCredithrs(int crdthrs){
        credithrs = crdthrs;
    }
    
    public void setName(String nombre){
        name = nombre;
    }
    
    public void setDepartment(String dprt){
        department = dprt;
    }
    
    public void setUpperCore(String core){
        upperCore = core;
    }
    
    public void setDescription(String descr){
        description = descr;
    }
    
    public void setPrerequisites(ArrayList prereqs){
        prerequisites = prereqs;
    }
    
    public void setRequired(ArrayList required){
        requiredFor = required;
    }
}
