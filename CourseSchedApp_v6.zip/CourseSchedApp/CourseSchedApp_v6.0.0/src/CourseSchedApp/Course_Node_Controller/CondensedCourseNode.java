/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CourseSchedApp.Course_Node_Controller;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Chris
 */
public class CondensedCourseNode extends JPanel implements Transferable{
    private JLabel dept_IdLabel;
    private Color  panelColor;
    private JPanel colorPanel;
    private JButton remove;
    private GridBagConstraints cons;
    private DataFlavor nodeFlavor;
    private int hours;
    
    public CondensedCourseNode(CourseNode cNode){
        this.setLayout(new GridBagLayout());
        dept_IdLabel = new JLabel(cNode.getOverview().getDepartment() + " " + cNode.getOverview().getId());
        panelColor = cNode.getOverview().getStatusColor();
        colorPanel = new JPanel();
        colorPanel.setBackground(panelColor);
        nodeFlavor = new DataFlavor(CondensedCourseNode.class, "Condensed Course Node");
        cons = new GridBagConstraints();
        remove = new JButton("Remove");
        hours = cNode.getCreditHours();
                
        setGridConstraints(cons, 0.5, 1.0, 0, 0, 2, 2);
        this.add(colorPanel, cons);
        setGridConstraints(cons, 1.0, 1.0, 1, 0, 2, 2);
        this.add(dept_IdLabel, cons);
        cons.gridx++;
        this.add(remove);
    }
    
    public void setGridConstraints(GridBagConstraints constraints, double wy, double wx, int x, int y, int padx, int pady){
        constraints.weightx = wx;
        constraints.weighty = wy;
        constraints.gridx = x;
        constraints.gridy = y;
        constraints.ipadx = padx;
        constraints.ipady = pady;
    }
    
    public JButton getRemoveButton(){
        return remove;
    }
    
    public String getCourseName(){
        return dept_IdLabel.getText();
    }
    
    public int getCreditHours(){
        return hours;
    }
    
    public JPanel getColorPanel(){
        return colorPanel;
    }
    
    @Override
    public CondensedCourseNode getTransferData(DataFlavor flavor){
        return this;
    }
    
    @Override
    public boolean isDataFlavorSupported(DataFlavor flavor){
        return Arrays.asList(getTransferDataFlavors()).contains(flavor);
    }
    
    @Override
    public DataFlavor[] getTransferDataFlavors(){
        return new DataFlavor[]{nodeFlavor};
    }
}
