/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CourseSchedApp.Course_Node_Controller;

import java.util.ArrayList;

/**
 *
 * @author Chris
 */
public class CourseObjectManager {
    
    public void CourseObjectManager(){
        
    }
    
    public void courseObjectCreation(String courses, ArrayList<Course> list){
        String splitString[] = courses.split("\\*");
        Course tempCourse = new Course();
        ArrayList<String> prereqs = new ArrayList();
        String splitRequired[];
        ArrayList<String> required;
        
        System.out.println(splitString.length);
        
        if(splitString.length > 1){
            for(int i = 0; i < splitString.length; i++){
                required = tempCourse.getRequired();
                
                tempCourse.setDepartment(splitString[i]);
                i++;
                tempCourse.setID(/*Integer.parseInt(*/splitString[i]);
                i++;
                
                if(splitString[i].length() > 200){
                    tempCourse.setName(splitString[i].substring(0,20));
                }
                else{
                    tempCourse.setName(splitString[i]);
                }
                
                i++;
                tempCourse.setCredithrs(Integer.parseInt(splitString[i]));
                i++;
                prereqs.add(splitString[i]);
                i++;
                prereqs.add(splitString[i]);
                i++;
                prereqs.add(splitString[i]);
                i++;
                prereqs.add(splitString[i]);
                tempCourse.setPrerequisites(prereqs);
                i++;
                tempCourse.setUpperCore(splitString[i]);
                i++;
                
                splitRequired = splitString[i].split(",");
                
                for(int j = 0; j < splitRequired.length; j++){
                    required.add(splitRequired[j]);
                }
                
                i++;
                tempCourse.setDescription(splitString[i]);

                list.add(tempCourse);
                
                prereqs = new ArrayList();
                tempCourse = new Course();
            }
        }
        else{
            System.out.println(splitString[0]);
        }
        courses = new String();
        splitString = new String[0];
    }
}
