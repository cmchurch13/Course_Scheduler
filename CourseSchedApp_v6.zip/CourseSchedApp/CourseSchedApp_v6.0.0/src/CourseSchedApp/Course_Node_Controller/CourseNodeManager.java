/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CourseSchedApp.Course_Node_Controller;

import CourseSchedApp.Scheduling.Planner;
import CourseSchedApp.Scheduling.Semester;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Calvin
 */
public class CourseNodeManager {
    /* Global Variable Declarations and Initializations */
    private CheckTaken takenLstnr = new CheckTaken();
    private CourseObjectManager objectMan= new CourseObjectManager();
    
    private ArrayList<CourseNode> CSCI_MAJ_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> CSCI_MAJ_ELEC_nodeList = new ArrayList();
    private ArrayList<CourseNode> CSCI_MIN_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> CSCI_MIN_ELEC_nodeList = new ArrayList();
    private ArrayList<CourseNode> CHEM_ACS_nodeList = new ArrayList();
    private ArrayList<CourseNode> CHEM_ACSB_nodeList = new ArrayList();
    private ArrayList<CourseNode> CHEM_CHEM_nodeList = new ArrayList();
    private ArrayList<CourseNode> CHEM_MIN_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> CHEM_MIN_ELEC_nodeList = new ArrayList();
    private ArrayList<CourseNode> MATH_BA_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> MATH_BA_ELEC_nodeList = new ArrayList();
    private ArrayList<CourseNode> MATH_PURE_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> MATH_PURE_ELEC_nodeList = new ArrayList();
    private ArrayList<CourseNode> MATH_APP_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> MATH_APP_ELEC_nodeList = new ArrayList();
    private ArrayList<CourseNode> MATH_MIN1_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> MATH_MIN1_ELEC_nodeList = new ArrayList();
    private ArrayList<CourseNode> MATH_MIN2_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> MATH_MIN2_ELEC_nodeList = new ArrayList();
    private ArrayList<CourseNode> MATH_STAT_nodeList = new ArrayList();
    private ArrayList<CourseNode> BIOL_MAJ_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> BIOL_MAJ_ELEC_nodeList = new ArrayList();
    private ArrayList<CourseNode> BIOL_MIN_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> BIOL_MIN_ELEC_nodeList = new ArrayList();
    private ArrayList<CourseNode> PHYS_PURE_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> PHYS_BIO_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> PHYS_CHEM_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> PHYS_MATH_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> PHYS_APP_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> PHYS_SCI_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> PHYS_MIN_CORE_nodeList = new ArrayList();
    private ArrayList<CourseNode> COURSE_CATALOG_nodeList = new ArrayList();
    private ArrayList<CourseNode> LOW_CORE_QUANT_nodeList = new ArrayList();
    private ArrayList<CourseNode> LOW_CORE_PSCI_nodeList = new ArrayList();
    private ArrayList<CourseNode> LOW_CORE_LSCI_nodeList = new ArrayList();
    private ArrayList<CourseNode> LOW_CORE_AHIST_nodeList = new ArrayList();
    private ArrayList<CourseNode> LOW_CORE_SSCI_nodeList = new ArrayList();
    private ArrayList<CourseNode> LOW_CORE_FART_nodeList = new ArrayList();
    private ArrayList<CourseNode> LOW_CORE_WFOUN_nodeList = new ArrayList();
    private ArrayList<CourseNode> LOW_CORE_RWRTN_nodeList = new ArrayList();
    private ArrayList<CourseNode> LOW_CORE_OCOMM_nodeList = new ArrayList();
    private ArrayList<CourseNode> LOW_CORE_CWORK_nodeList = new ArrayList();
    private ArrayList<CourseNode> LOW_CORE_WCULT_nodeList = new ArrayList();
    private ArrayList<CourseNode> LOW_CORE_RLIV_nodeList = new ArrayList();
    
    private ArrayList<ArrayList> allCourseNodes = new ArrayList();
    
    private ArrayList<Course> courseList = new ArrayList();
    
    
    public CourseNodeManager(){
        allCourseNodes.add(CSCI_MAJ_CORE_nodeList);
        allCourseNodes.add(CSCI_MAJ_ELEC_nodeList);
        allCourseNodes.add(CSCI_MIN_CORE_nodeList);
        allCourseNodes.add(CSCI_MIN_ELEC_nodeList);
        allCourseNodes.add(CHEM_ACS_nodeList);
        allCourseNodes.add(CHEM_ACSB_nodeList);
        allCourseNodes.add(CHEM_CHEM_nodeList);
        allCourseNodes.add(CHEM_MIN_CORE_nodeList);
        allCourseNodes.add(CHEM_MIN_ELEC_nodeList);
        allCourseNodes.add(MATH_BA_CORE_nodeList);
        allCourseNodes.add(MATH_BA_ELEC_nodeList);
        allCourseNodes.add(MATH_PURE_CORE_nodeList);
        allCourseNodes.add(MATH_PURE_ELEC_nodeList);
        allCourseNodes.add(MATH_APP_CORE_nodeList);
        allCourseNodes.add(MATH_APP_ELEC_nodeList);
        allCourseNodes.add(MATH_MIN1_CORE_nodeList);
        allCourseNodes.add(MATH_MIN1_ELEC_nodeList);
        allCourseNodes.add(MATH_MIN2_CORE_nodeList);
        allCourseNodes.add(MATH_MIN2_ELEC_nodeList);
        allCourseNodes.add(MATH_STAT_nodeList);
        allCourseNodes.add(BIOL_MAJ_CORE_nodeList);
        allCourseNodes.add(BIOL_MAJ_ELEC_nodeList);
        allCourseNodes.add(BIOL_MIN_CORE_nodeList);
        allCourseNodes.add(BIOL_MIN_ELEC_nodeList);
        allCourseNodes.add(BIOL_MIN_ELEC_nodeList);
        allCourseNodes.add(PHYS_PURE_CORE_nodeList);
        allCourseNodes.add(PHYS_APP_CORE_nodeList);
        allCourseNodes.add(PHYS_BIO_CORE_nodeList);
        allCourseNodes.add(PHYS_CHEM_CORE_nodeList);
        allCourseNodes.add(PHYS_MATH_CORE_nodeList);
        allCourseNodes.add(PHYS_SCI_CORE_nodeList);
        allCourseNodes.add(COURSE_CATALOG_nodeList);
        allCourseNodes.add(PHYS_MIN_CORE_nodeList); 
        allCourseNodes.add(LOW_CORE_QUANT_nodeList);
        allCourseNodes.add(LOW_CORE_PSCI_nodeList);
        allCourseNodes.add(LOW_CORE_LSCI_nodeList);
        allCourseNodes.add(LOW_CORE_AHIST_nodeList);
        allCourseNodes.add(LOW_CORE_SSCI_nodeList);
        allCourseNodes.add(LOW_CORE_FART_nodeList);
        allCourseNodes.add(LOW_CORE_WFOUN_nodeList);
        allCourseNodes.add(LOW_CORE_RWRTN_nodeList);
        allCourseNodes.add(LOW_CORE_OCOMM_nodeList);
        allCourseNodes.add(LOW_CORE_CWORK_nodeList);
        allCourseNodes.add(LOW_CORE_WCULT_nodeList);
        allCourseNodes.add(LOW_CORE_RLIV_nodeList); 
    }
    
    public void courseCreation(String courses){
        int i = 0;
        
        objectMan.courseObjectCreation(courses, courseList);
        
        for(Course c : courseList){
            i++;
        }
        
        System.out.println(i);
    }
    
    /**
     * Creates full track panel from course list
     * 
     * @param CL 
     * @param panel 
     */
    public void nodeCreation(){    

        //This loops through the array of Courses and creates CourseNodes
        for (Course CL1 : courseList) {
            CourseNode nextNode = new CourseNode(CL1,takenLstnr);
            
            for(String req : CL1.getRequired()){
                
                
                if (req.equals("CORE_MAJ_CHEM_ALL")) {
                    CHEM_ACS_nodeList.add(new CourseNode(nextNode));
                    CHEM_ACSB_nodeList.add(new CourseNode(nextNode));
                    CHEM_CHEM_nodeList.add(new CourseNode(nextNode));
                } 

                else if (req.equals("CORE_MAJ_CHEM_ACS")) {
                    CHEM_ACS_nodeList.add(new CourseNode(nextNode));
                }

                else if (req.equals("CORE_MAJ_CHEM_ACSB")) {
                    CHEM_ACSB_nodeList.add(new CourseNode(nextNode));
                } 

                else if (req.equals("CORE_MAJ_CHEM_CHEM")) {
                    CHEM_CHEM_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MIN_CHEM_CHEM")){
                    CHEM_MIN_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("ELEC_MIN_CHEM_CHEM")){
                    CHEM_MIN_ELEC_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MAJ_CSCI_COMP")){
                    CSCI_MAJ_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("ELEC_MAJ_CSCI_COMP")){
                    CSCI_MAJ_ELEC_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MIN_CSCI_COMP")){
                    CSCI_MIN_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("ELEC_MIN_CSCI_COMP")){
                    CSCI_MIN_ELEC_nodeList.add(new CourseNode(nextNode));
                }

                else if (req.equals("CORE_MAJ_MATH_BA")){
                    MATH_BA_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("ELEC_MAJ_MATH_BA")){
                    MATH_BA_ELEC_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MAJ_MATH_ALLBS")){
                    MATH_PURE_CORE_nodeList.add(new CourseNode(nextNode));
                    MATH_APP_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MAJ_MATH_PURE")){
                    MATH_PURE_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("ELEC_MAJ_MATH_PURE")){
                    MATH_PURE_ELEC_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MAJ_MATH_APP")){
                    MATH_APP_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("ELEC_MAJ_MATH_APP")){
                    MATH_APP_ELEC_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MIN_MATH_1")){
                    MATH_MIN1_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("ELEC_MIN_MATH_1")){
                    MATH_MIN1_ELEC_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MIN_MATH_2")){
                    MATH_MIN2_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("ELEC_MIN_MATH_2")){
                    MATH_MIN2_ELEC_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MIN_MATH_STAT")){
                    MATH_STAT_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MAJ_BIOL_ALL")){
                    BIOL_MAJ_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("ELEC_MAJ_BIOL_ALL")){
                    BIOL_MAJ_ELEC_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("ELEC_MIN_BIOL_ALL")){
                    BIOL_MIN_ELEC_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MIN_BIOL_ALL")){
                    BIOL_MIN_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MAJ_PHYS_ALL")){
                    PHYS_PURE_CORE_nodeList.add(new CourseNode(nextNode));
                    PHYS_MATH_CORE_nodeList.add(new CourseNode(nextNode));
                    PHYS_BIO_CORE_nodeList.add(new CourseNode(nextNode));
                    PHYS_CHEM_CORE_nodeList.add(new CourseNode(nextNode));
                    PHYS_APP_CORE_nodeList.add(new CourseNode(nextNode));
                    PHYS_SCI_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MAJ_PHYS_PURE")){
                    PHYS_PURE_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MAJ_PHYS_BIO")){
                    PHYS_BIO_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MAJ_PHYS_CHEM")){
                    PHYS_CHEM_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MAJ_PHYS_MATH")){
                    PHYS_MATH_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MAJ_PHYS_SCI")){
                    PHYS_SCI_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MAJ_PHYS_APP")){
                    PHYS_APP_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_MIN_PHYS_ALL")){
                    PHYS_MIN_CORE_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_LOW_QUANT_ALL")){
                    LOW_CORE_QUANT_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_LOW_PSCI_ALL")){
                    LOW_CORE_PSCI_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_LOW_LSCI_ALL")){
                    LOW_CORE_LSCI_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_LOW_AHIST_ALL")){
                    LOW_CORE_AHIST_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_LOW_SSCI_ALL")){
                    LOW_CORE_SSCI_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_LOW_FART_ALL")){
                    LOW_CORE_FART_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_LOW_WFOUN_ALL")){
                    LOW_CORE_WFOUN_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_LOW_RWRTN_ALL")){
                    LOW_CORE_RWRTN_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_LOW_OCOMM_ALL")){
                    LOW_CORE_OCOMM_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_LOW_CWORK_ALL")){
                    LOW_CORE_CWORK_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_LOW_WCULT_ALL")){
                    LOW_CORE_WCULT_nodeList.add(new CourseNode(nextNode));
                }
                
                else if (req.equals("CORE_LOW_RLIV_ALL")){
                    LOW_CORE_RLIV_nodeList.add(new CourseNode(nextNode));
                }
                
                else{
                } 
            }
            COURSE_CATALOG_nodeList.add(nextNode);
        }
    }
    
   
    
    public void panelCreation(JPanel corePanel, JPanel electivesPanel, String dept, String track, boolean view){
        System.out.println("getDepartment test: " + CSCI_MAJ_CORE_nodeList.get(0).getDepartment());
        System.out.println("dept value test: " + dept);
        System.out.println("track value test: " + track);
        
        corePanel.removeAll();
        corePanel.repaint();    //XXX
        corePanel.revalidate(); //XXX
        
        if(electivesPanel != null){
            electivesPanel.removeAll();
        }

        /* Computer Science Major */
        if(track.equalsIgnoreCase("MAJ CSCI COMPUTER SCIENCE")){
           trackToPanel(corePanel, CSCI_MAJ_CORE_nodeList, view);
           trackToPanel(electivesPanel, CSCI_MAJ_ELEC_nodeList, view);
        }
        
        /* Computer Science Minor */
        else if(track.equalsIgnoreCase("MIN CSCI COMPUTER SCIENCE")){
            trackToPanel(corePanel, CSCI_MIN_CORE_nodeList, view);
            trackToPanel(electivesPanel, CSCI_MIN_ELEC_nodeList, view);
        }
        
        /* Chemistry Major ACS Certified */
        else if(track.equalsIgnoreCase("MAJ CHEM ACS CERTIFIED")){
            trackToPanel(corePanel, CHEM_ACS_nodeList, view);
        }
        
        /* Chemistry Major ACS Certified in Biochemistry */
        else if(track.equalsIgnoreCase("MAJ CHEM ACS IN BIOCHEMISTRY")){
            trackToPanel(corePanel, CHEM_ACSB_nodeList, view);
        }
        
        /* Chemistry Major non-ACS Certified */
        else if(track.equalsIgnoreCase("MAJ CHEM NON-ACS")){
            trackToPanel(corePanel, CHEM_CHEM_nodeList, view);
        }
        
        /* Chemistry Minor */
        else if(track.equalsIgnoreCase("MIN CHEM CHEMISTRY")){
            trackToPanel(corePanel, CHEM_MIN_CORE_nodeList, view);
            trackToPanel(electivesPanel, CHEM_MIN_ELEC_nodeList, view);
        }
        
        /* Mathematics Major Bachelor of Arts */
        else if(track.equalsIgnoreCase("MAJ MATH Bachelor of Arts")){
            trackToPanel(corePanel, MATH_BA_CORE_nodeList, view);
            trackToPanel(electivesPanel, MATH_BA_ELEC_nodeList, view);
        }
        
        /* Mathematics Major Pure Mathematics */
        else if(track.equalsIgnoreCase("MAJ MATH Pure Math")){
            trackToPanel(corePanel, MATH_PURE_CORE_nodeList, view);
            trackToPanel(electivesPanel, MATH_PURE_ELEC_nodeList, view);
        }
        
        /* Mathematics Major Applied Mathematics */
        else if(track.equalsIgnoreCase("MAJ MATH Applied Math")){
            trackToPanel(corePanel, MATH_APP_CORE_nodeList, view);
            trackToPanel(electivesPanel, MATH_APP_ELEC_nodeList, view);
        }
        
        /* Mathematics Minor #1 */
        else if(track.equalsIgnoreCase("MIN MATH Mathematics 1")){
            trackToPanel(corePanel, MATH_MIN1_CORE_nodeList, view);
            trackToPanel(electivesPanel, MATH_MIN1_ELEC_nodeList, view);
        }
        
        /* Mathematics Minor #2 */
        else if(track.equalsIgnoreCase("MIN MATH Mathematics 2")){
            trackToPanel(corePanel, MATH_MIN2_CORE_nodeList, view);
            trackToPanel(electivesPanel, MATH_MIN2_ELEC_nodeList, view);
        }
        
        /* Mathematics Minor in Statistics */
        else if(track.equalsIgnoreCase("MIN MATH Statistics")){
            trackToPanel(corePanel, MATH_STAT_nodeList, view);
        }
        
        /* Biology Major */
        else if(track.equalsIgnoreCase("MAJ BIOL Biology")){
            trackToPanel(corePanel, BIOL_MAJ_CORE_nodeList, view);
            trackToPanel(electivesPanel, BIOL_MAJ_ELEC_nodeList, view);
        }
        
        /* Biology Minor */
        else if(track.equalsIgnoreCase("MIN BIOL Biology")){
            trackToPanel(corePanel, BIOL_MIN_CORE_nodeList, view);
            trackToPanel(electivesPanel, BIOL_MIN_ELEC_nodeList, view);
        }
        
        /* Pure Physics Major */
        else if(track.equalsIgnoreCase("MAJ PHYS Pure Physics")){
            trackToPanel(corePanel, PHYS_PURE_CORE_nodeList, view);
        }
        
        /* Pure Physics Major */
        else if(track.equalsIgnoreCase("MAJ PHYS Applied Physics")){
            trackToPanel(corePanel, PHYS_APP_CORE_nodeList, view);
        }
        
        /* Pure Physics Major */
        else if(track.equalsIgnoreCase("MAJ PHYS Biological Physics")){
            trackToPanel(corePanel, PHYS_BIO_CORE_nodeList, view);
        }
        
        /* Pure Physics Major */
        else if(track.equalsIgnoreCase("MAJ PHYS Chemical Physics")){
            trackToPanel(corePanel, PHYS_CHEM_CORE_nodeList, view);
        }
        
        /* Pure Physics Major */
        else if(track.equalsIgnoreCase("MAJ PHYS Mathematical Physics")){
            trackToPanel(corePanel, PHYS_MATH_CORE_nodeList, view);
        }
        
        /* Pure Physics Major */
        else if(track.equalsIgnoreCase("MAJ PHYS Physical Science")){
            trackToPanel(corePanel, PHYS_SCI_CORE_nodeList, view);
        }
        
        else if(track.equalsIgnoreCase("MIN PHYS Physics")){
            trackToPanel(corePanel, PHYS_MIN_CORE_nodeList, view);
        }
        
        else if(track.equalsIgnoreCase("LOW Quantitative")){
            trackToPanel(corePanel, LOW_CORE_QUANT_nodeList, view);
        }
        
        else if(track.equalsIgnoreCase("LOW Quantitative")){
            trackToPanel(corePanel, LOW_CORE_QUANT_nodeList, view);
        }
        
        else if(track.equalsIgnoreCase("LOW Physical Science")){
            trackToPanel(corePanel, LOW_CORE_PSCI_nodeList, view);
        }
        
        else if(track.equalsIgnoreCase("LOW Life Science")){
            trackToPanel(corePanel, LOW_CORE_LSCI_nodeList, view);
        }
        
        else if(track.equalsIgnoreCase("LOW American History and Government")){
            trackToPanel(corePanel, LOW_CORE_AHIST_nodeList, view);
        }
        
        else if(track.equalsIgnoreCase("LOW Social Science")){
            trackToPanel(corePanel, LOW_CORE_SSCI_nodeList, view);
        }
        
        else if(track.equalsIgnoreCase("LOW Fine Arts/Humanities")){
            trackToPanel(corePanel, LOW_CORE_FART_nodeList, view);
        }
        
        else if(track.equalsIgnoreCase("LOW Writing Foundation")){
            trackToPanel(corePanel, LOW_CORE_WFOUN_nodeList, view);
        }
        
        else if(track.equalsIgnoreCase("LOW Research and Writing")){
            trackToPanel(corePanel, LOW_CORE_RWRTN_nodeList, view);
        }
        
        else if(track.equalsIgnoreCase("LOW Oral Communication")){
            trackToPanel(corePanel, LOW_CORE_OCOMM_nodeList, view);
        }
        
        else if(track.equalsIgnoreCase("LOW Creative Works")){
            trackToPanel(corePanel, LOW_CORE_CWORK_nodeList, view);
        }
        
        else if(track.equalsIgnoreCase("LOW World Cultures")){
            trackToPanel(corePanel, LOW_CORE_WCULT_nodeList, view);
        }
        
        else if(track.equalsIgnoreCase("LOW Responsible Living")){
            trackToPanel(corePanel, LOW_CORE_RLIV_nodeList, view);
        }
        
        else{}
        
        corePanel.repaint();
        corePanel.revalidate();
        
        if(electivesPanel != null){
            electivesPanel.repaint();
            electivesPanel.revalidate();
        }
        
        evaluatePrerequisites();
    }
    
    public void singlePanelCreation(JPanel byDepartment, String dept) {
        byDepartment.removeAll();
        int courseCount = 0;
        
        for(CourseNode CN1 : COURSE_CATALOG_nodeList){
            if (dept.equals(CN1.getDepartment())){
                courseCount++;
            }
        }
        
        byDepartment.setLayout(new GridLayout(4,(courseCount/4)+1, 5, 5));
        
        for(CourseNode CN1 : COURSE_CATALOG_nodeList){
            if (dept.equals(CN1.getDepartment())){
                byDepartment.add(CN1);
            }
        }
        
        byDepartment.repaint();
        byDepartment.revalidate();
        
        evaluatePrerequisites();
        
    }
    
    public void trackToPanel(JPanel panel, ArrayList<CourseNode> trackList, boolean view){
        panel.setLayout(new GridLayout(4, 1, 5, 5));
        
        if(view){
            for (CourseNode NL1 : trackList){
                panel.add(NL1);
            }
            
            if(panel.getComponentCount() < 16){
                for(int i = 0; panel.getComponentCount() < 16; i++){
                    JTabbedPane emptyPane = new JTabbedPane();
                    emptyPane.setVisible(false);
                    panel.add(emptyPane);
                }
            }
        }
        
        else {
            listCreation(panel, trackList);
        }
    }
    
    private void listCreation(JPanel trackPanel, ArrayList<CourseNode> trackList){
        JTable table1 = new JTable();
        
        System.out.println("\nDepartment of first course: " + trackList.get(0).getDepartment());
        
        List<Object[]> list = new ArrayList<Object[]>();
        list.add(new Object[] {
                        "Department",
                        "ID",
                        "Course Title",
                        "Credit Hours"
        });
        
        for (CourseNode CN1 : trackList) {
            OverviewPanel overPanel = (OverviewPanel) CN1.getComponent(0);
            
            list.add(new Object[] { 
                              overPanel.getDepartment(), 
                              overPanel.getId(),
                              overPanel.getCourseName(),
                              overPanel.getCreditHour()
                          });
            }
        table1.setModel(new DefaultTableModel(list.toArray(new Object[][] {}), new String[] {"Department", "ID", "Course Title", "Credit Hours"}));
        table1.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        
        trackPanel.removeAll();
        trackPanel.add(table1);
        
        trackPanel.repaint();
        trackPanel.revalidate();
    }
    
    /**
     * Checks for passed prerequisites then paints the course color appropriately
     * 
     * @param tree 
     */
    public void evaluatePrerequisites(){
        for(ArrayList<CourseNode> nextList : allCourseNodes){
            for(CourseNode nextNode : nextList){
                if(nextNode.getTabCount() >= 2){
                    JPanel prereqPanel2 = (JPanel) nextNode.getComponent(2);
                    JPanel prereqPanel1 = (JPanel) nextNode.getComponent(1);
                    JPanel overPanel = (JPanel) nextNode.getComponent(0);
                    JCheckBox passedBox_1 = (JCheckBox) prereqPanel1.getComponent(2);
                    JCheckBox passedBox_2 = (JCheckBox) prereqPanel1.getComponent(5);
                    JCheckBox passedBox_3 = (JCheckBox) prereqPanel2.getComponent(2);
                    JCheckBox passedBox_4 = (JCheckBox) prereqPanel2.getComponent(5);
                    JCheckBox takenBox = (JCheckBox) overPanel.getComponent(2);
                    JPanel color = (JPanel) overPanel.getComponent(0);
                    JTextArea nameArea = (JTextArea) overPanel.getComponent(1);
                    String name = nameArea.getText().substring(0,9);
                    boolean passed_1 = passedBox_1.isSelected();
                    boolean passed_2 = passedBox_2.isSelected();
                    boolean passed_3 = passedBox_3.isSelected();
                    boolean passed_4 = passedBox_4.isSelected();
                    boolean text_1 = (!"NONE".equals(((JTextField) prereqPanel1.getComponent(1)).getText()));
                    boolean text_2 = (!"NONE".equals(((JTextField) prereqPanel1.getComponent(4)).getText()));
                    boolean text_3 = (!"NONE".equals(((JTextField) prereqPanel2.getComponent(1)).getText()));
                    boolean text_4 = (!"NONE".equals(((JTextField) prereqPanel2.getComponent(4)).getText()));
                    boolean taken = (takenBox.isSelected());
                    
                    if(!taken){
                        if((text_1 && text_2 && passed_1 && passed_2) || (text_1 && passed_1 && !text_2) || (!text_1 && !text_2)){
                            if((text_3 && text_4 && passed_3 && passed_4) || (text_3 && passed_3 && !text_4) || (!text_3 && !text_4)){
                                color.setBackground(new Color(0,0,150));
                                color.repaint();
                                color.revalidate();
                                
                                for(Semester SP : Planner.getSemesters()){
                                    for(CondensedCourseNode CCN : SP.getCourseList()){
                                        if(name.equals(CCN.getCourseName())){
                                            CCN.getColorPanel().setBackground(new Color(0,0,150));
                                            CCN.getColorPanel().repaint();
                                            CCN.getColorPanel().revalidate();
                                        }
                                    }
                                }
                            }
                            else{
                                color.setBackground(new Color(150,0,0));
                                color.repaint();
                                color.revalidate();
                                
                                for(Semester SP : Planner.getSemesters()){
                                    for(CondensedCourseNode CCN : SP.getCourseList()){
                                        if(name.equals(CCN.getCourseName())){
                                            CCN.getColorPanel().setBackground(new Color(150,0,0));
                                            CCN.getColorPanel().repaint();
                                            CCN.getColorPanel().revalidate();
                                        }
                                    }
                                }
                            }
                        }
                        else{
                            color.setBackground(new java.awt.Color(150,0,0));
                            color.repaint();
                            color.revalidate();
                            
                            for(Semester SP : Planner.getSemesters()){
                                for(CondensedCourseNode CCN : SP.getCourseList()){
                                    if(name.equals(CCN.getCourseName())){
                                        CCN.getColorPanel().setBackground(new Color(150,0,0));
                                        CCN.getColorPanel().repaint();
                                        CCN.getColorPanel().revalidate();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Marks Prerequisites as passed or not
     * 
     * @param tree
     * @param name
     * @param passed 
     */
    public void checkOffPrerequisites(String name, boolean passed){
        for(ArrayList<CourseNode> nextList : allCourseNodes){
            for(CourseNode nextNode : nextList){

                if(nextNode.getTabCount() >= 2){
                    OverviewPanel overPanel = (OverviewPanel) nextNode.getComponent(0);
                    JPanel color = (JPanel) overPanel.getComponent(0);
                    JTextArea titleArea = (JTextArea) overPanel.getComponent(1);
                    JCheckBox takenBox = (JCheckBox) overPanel.getComponent(2);
                    String courseName = titleArea.getText().substring(0,9);
                    JPanel prereqPanel1 = (JPanel) nextNode.getComponent(1);
                    JPanel prereqPanel2 = (JPanel) nextNode.getComponent(2);
                    JCheckBox prereq_1CheckBox = (JCheckBox) prereqPanel1.getComponent(2);
                    JCheckBox prereq_2CheckBox = (JCheckBox) prereqPanel1.getComponent(5);
                    JCheckBox prereq_3CheckBox = (JCheckBox) prereqPanel2.getComponent(2);
                    JCheckBox prereq_4CheckBox = (JCheckBox) prereqPanel2.getComponent(5);
                    String prereq_1 = ((JTextField) prereqPanel1.getComponent(1)).getText();
                    String prereq_2 = ((JTextField) prereqPanel1.getComponent(4)).getText();
                    String prereq_3 = ((JTextField) prereqPanel2.getComponent(1)).getText();
                    String prereq_4 = ((JTextField) prereqPanel2.getComponent(4)).getText();

                    if(name.equals(courseName)){
                        if(passed){
                            takenBox.setSelected(true);
                            color.setBackground(new java.awt.Color(0,150,0));
                            color.repaint();
                            color.revalidate();
                        }
                        else{
                            takenBox.setSelected(false);
                        }         
                    }
                    else if(prereq_1.equals(name)){
                        if(passed){
                            prereq_1CheckBox.setSelected(true);
                        }
                        else{
                            prereq_1CheckBox.setSelected(false);
                        }
                    }
                    else if(prereq_2.equals(name)){
                        if(passed){
                            prereq_2CheckBox.setSelected(true);
                        }
                        else{
                            prereq_2CheckBox.setSelected(false);
                        }
                    }
                    else if(prereq_3.equals(name)){
                        if(passed){
                            prereq_3CheckBox.setSelected(true);
                        }
                        else{
                            prereq_3CheckBox.setSelected(false);
                        }
                    }
                    else if(prereq_4.equals(name)){
                        if(passed){
                            prereq_4CheckBox.setSelected(true);
                        }
                        else{
                            prereq_4CheckBox.setSelected(false);
                        }
                    }
                    
                    else{}
                }
            }
        }    
    }
    
    class CheckTaken implements ActionListener{
        @Override public void actionPerformed(ActionEvent e){
            Color cannotTake = new Color(150,0,0);
            boolean passed = true;
            JCheckBox box = (JCheckBox) e.getSource();
            JPanel overPanel = (JPanel) box.getParent();
            JPanel color = (JPanel)overPanel.getComponent(0);
            JTabbedPane pane = (JTabbedPane) overPanel.getParent();
            JPanel tree = (JPanel) pane.getParent();
            JTextArea courseName = (JTextArea) overPanel.getComponent(1);
            String name = courseName.getText().substring(0,9);
                
            if(box.isSelected()){
                if(color.getBackground().getRGB() == cannotTake.getRGB()){
                    JOptionPane.showMessageDialog(pane, "You have not taken the required PREREQUISITES\nfor this course");
                }
                color.setBackground(new java.awt.Color(0,150,0));
                color.repaint();
                color.revalidate();
                
                for(Semester SP : Planner.getSemesters()){
                    for(CondensedCourseNode CCN : SP.getCourseList()){
                        if(name.equals(CCN.getCourseName())){
                            CCN.getColorPanel().setBackground(new Color(0,150,0));
                            CCN.getColorPanel().repaint();
                            CCN.getColorPanel().revalidate();
                        }
                    }
                }
            }
                
            else{
               color.setBackground(new java.awt.Color(0,0,150));
               color.repaint();
               color.revalidate();
               passed = false;
               
               for(Semester SP : Planner.getSemesters()){
                    for(CondensedCourseNode CCN : SP.getCourseList()){
                        if(name.equals(CCN.getCourseName())){
                            CCN.getColorPanel().setBackground(new Color(0,0,150));
                            CCN.getColorPanel().repaint();
                            CCN.getColorPanel().revalidate();
                        }
                    }
                }
            }
            
            checkOffPrerequisites(name,passed);
            evaluatePrerequisites();
        }
    }
}
